import re


class CustomAttributeError(Exception):
    """Custom error for setting read-only properties."""

    pass


def extract_error_message(error_text):
    """
    Extract the core error message between 'Bad Request - error creating job:'
    and 'the request is not valid'
    """
    pattern = r"Bad Request - error creating job:?\s*(.*?)(?:the request is not valid|$)"
    match = re.search(pattern, error_text, re.DOTALL | re.IGNORECASE)

    if match:
        return match.group(1).strip()[:-1]
    else:
        return error_text
