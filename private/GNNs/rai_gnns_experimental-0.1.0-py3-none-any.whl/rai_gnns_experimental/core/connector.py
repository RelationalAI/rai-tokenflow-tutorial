import json
from typing import Dict, Optional

import snowflake.connector
from pydantic import BaseModel, Field, PrivateAttr, model_validator
from snowflake.snowpark import Session

from rai_gnns_experimental.common.job_models import PayloadTypes

from .provider import Provider

ENGINE_TYPE_GNN = "ML"


class BaseConnector(BaseModel):
    """Base class for all connector types."""

    connector_type: str
    headers: Dict = Field(default_factory=dict)
    is_native_app: bool = False
    endpoint_url: Optional[str] = None


class LocalConnector(BaseConnector):
    """Connector for establishing a local connection."""

    connector_type: str
    port: Optional[int] = None
    url: Optional[str] = None

    @model_validator(mode="after")
    def validate_url_configuration(self) -> "LocalConnector":
        """Ensures proper URL configuration and builds endpoint_url if needed."""
        if not self.endpoint_url:
            if not (self.url and self.port):
                raise ValueError("Either endpoint_url or both url and port must be provided")
            self.endpoint_url = f"{self.url}:{self.port}"
        return self


class SnowflakeConnectorDirectAccess(BaseConnector):
    """Connector for Snowflake with direct access."""

    # Fixed connector properties
    connector_type: str = Field(default="snowflake", frozen=True)

    # Credential properties
    user: str
    password: str
    account: str
    # Configuration properties
    endpoint_url: Optional[str] = None
    # Request properties
    headers: Dict[str, str] = Field(default_factory=dict, exclude=True)
    # Private properties - not included in serialization
    _session: Optional[Session] = PrivateAttr(default=None)

    class Config:
        arbitrary_types_allowed = True

    @model_validator(mode="after")
    def infer_headers(self) -> "SnowflakeConnector":
        """Automatically retrieves and sets Snowflake authentication token."""
        try:
            # Prepare token for the request headers
            ctx = snowflake.connector.connect(
                user=self.user,
                password=self.password,
                account=self.account,
                session_parameters={"PYTHON_CONNECTOR_QUERY_RESULT_FORMAT": "json"},
            )

            # Fetch session token
            token_data = ctx._rest._token_request("ISSUE")
            token = token_data.get("data", {}).get("sessionToken")

            if not token:
                raise ValueError("Failed to retrieve session token from Snowflake")

            # Set authentication header
            self.headers = {"Authorization": f'Snowflake Token="{token}"'}

        except Exception as e:
            raise ConnectionError(f"Failed to connect to Snowflake: {e}") from e

        return self


class SnowflakeConnector(BaseConnector, Provider):
    """Connector for Snowflake."""

    # Fixed connector properties
    connector_type: str = Field(default="snowflake", frozen=True)

    # Credential properties
    user: str
    password: Optional[str] = None
    account: str
    warehouse: str
    app_name: Optional[str] = None
    auth_method: Optional[str] = None
    private_key_path: Optional[str] = None
    private_key_passphrase: Optional[str] = None
    oauth_token: Optional[str] = None
    host: Optional[str] = None

    # Configuration properties
    engine_name: Optional[str] = None
    mlflow_autosuspend_timeout: int = Field(default=5, ge=1)
    is_native_app: bool = True

    # Private properties - not included in serialization
    _session: Optional[Session] = PrivateAttr(default=None)
    mlflow_session_url: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True

    def model_post_init(self, __context) -> None:
        self._initialize_session()
        self._setup_resources()

    def _setup_resources(self):
        payload = {
            "payload_type": PayloadTypes.MONITOR_MLFLOW_LOGS,
            "user_id": self.user,
            "minutes_threshold": self.mlflow_autosuspend_timeout,
        }

        try:
            engine_details = self._get_gnn_engine_details(self.engine_name)
            engine_status = engine_details[0]["STATUS"]
            mlflow_session_url = json.loads(engine_details[0]["SETTINGS"])["mlflowendpoint"]["ingress_url"]
            self.mlflow_session_url = f"https://{mlflow_session_url}"

            if engine_status != "READY":
                raise RuntimeError(f"Engine '{self.engine_name}' is not ready (status: {engine_status})")

            return self.exec_job(payload)

        except Exception as e:
            print(f"❌ Please ensure your engine '{self.engine_name}' exists and in a READY state. {e}")
            return None

    def cancel_job(self, job_id: str):
        res = self._exec(f"CALL {self.app_name}.experimental.cancel_job('{ENGINE_TYPE_GNN}', '{job_id}');")
        return res

    def exec_job(self, payload):
        # Convert payload to JSON
        payload_json = json.dumps(payload)

        # Execute the async job
        sql_query = f"CALL \
            {self.app_name}.experimental.exec_job_async('{ENGINE_TYPE_GNN}', '{self.engine_name}', '{payload_json}')"
        # results will contain (job_id, state, data)
        results = self._exec(sql_query)

        # Extract job information
        data = results[0].DATA
        data = json.loads(data)
        return data

    def get_job_metadata(self, job_id: str):
        res = self._exec(f"CALL {self.app_name}.experimental.get_job_metadata('{ENGINE_TYPE_GNN}', '{job_id}');")
        res_metadata = json.loads(res[0]["RESULT_METADATA"])
        return res_metadata

    def get_job_events(self, job_id: str, continuation_token: str = ""):
        results = self._exec(
            f"SELECT {self.app_name}.experimental.get_job_events('{ENGINE_TYPE_GNN}', '{job_id}', '{continuation_token}');"
        )
        if not results:
            return {"events": [], "continuation_token": None}
        row = results[0][0]
        return json.loads(row)

    def get_job(self, job_id: str):
        results = self._exec(f"CALL {self.app_name}.experimental.get_job('{ENGINE_TYPE_GNN}', '{job_id}');")
        return self.job_list_to_dicts(results)

    def list_jobs(self, state=None, limit=None):
        state_clause = f"AND STATE = '{state.upper()}'" if state else ""
        limit_clause = f"LIMIT {limit}" if limit else ""
        results = self._exec(
            f"SELECT ID,STATE,CREATED_BY,CREATED_ON,FINISHED_AT,DURATION,PAYLOAD,ENGINE_NAME \
            FROM {self.app_name}.experimental.jobs \
            where type='{ENGINE_TYPE_GNN}' {state_clause} ORDER BY created_on DESC {limit_clause};"
        )
        return self.job_list_to_dicts(results)

    def _get_gnn_engine_details(self, name: str):
        """Get the GNN engine details."""
        results = self._exec(f"CALL {self.app_name}.experimental.get_engine('{ENGINE_TYPE_GNN}', '{name}');")
        return results

    @staticmethod
    def job_list_to_dicts(results):
        if not results:
            return []
        return [
            {
                "job_id": row["ID"],
                "status": row["STATE"],
                "created_by": row["CREATED_BY"],
                "created_on": row["CREATED_ON"],
                "finished_at": row["FINISHED_AT"],
                "duration": row["DURATION"] if "DURATION" in row else 0,
                "engine": row["ENGINE_NAME"],
                "payload_type": json.loads(row["PAYLOAD"])["payload_type"],
            }
            for row in results
        ]
