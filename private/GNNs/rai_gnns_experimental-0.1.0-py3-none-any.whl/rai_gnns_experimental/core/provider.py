import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

from cryptography.hazmat.primitives import serialization
from snowflake.snowpark import Session
from snowflake.snowpark.exceptions import SnowparkSQLException

ENGINE_TYPE_GNN = "ML"


class Provider:
    def __init__(
        self,
        account: str,
        warehouse: str,
        app_name: str,
        user: Optional[str] = None,
        auth_method: str = "password",
        password: Optional[str] = None,
        private_key_path: Optional[Union[str, Path]] = None,
        private_key_passphrase: Optional[str] = None,
        oauth_token: Optional[str] = None,
        host: Optional[str] = None,
    ):
        """
        Initialize a new Provider instance with support for multiple authentication methods.

        :param account: Snowflake account identifier.
        :type account: str
        :param warehouse: Snowflake warehouse.
        :type warehouse: str
        :param app_name: Snowflake Native app name.
        :type app_name: str
        :param user: Snowflake username (required for password and key_pair auth).
        :type user: Optional[str]
        :param auth_method: Authentication method ('password', 'key_pair', 'browser', or 'oauth'). Defaults to
            'password'.
        :type auth_method: str
        :param password: Snowflake password (required if auth_method is 'password').
        :type password: Optional[str]
        :param private_key_path: Path to private key file (required if auth_method is 'key_pair').
        :type private_key_path: Optional[Union[str, Path]]
        :param private_key_passphrase: Optional passphrase for encrypted private key.
        :type private_key_passphrase: Optional[str]
        :param oauth_token: OAuth access token (required if auth_method is 'oauth').
        :type oauth_token: Optional[str]
        :param host: Optional Snowflake host for OAuth authentication.
        :type host: Optional[str]
        """
        self.account = account
        self.warehouse = warehouse
        self.app_name = app_name
        self.user = user
        self.auth_method = auth_method.lower()
        self.password = password
        self.private_key_path = private_key_path
        self.private_key_passphrase = private_key_passphrase
        self.oauth_token = oauth_token
        self.host = host

        # Validate authentication parameters
        if self.auth_method not in ["password", "key_pair", "browser", "oauth"]:
            raise ValueError("auth_method must be one of: 'password', 'key_pair', 'browser', 'oauth'")

        if self.auth_method == "password":
            if not user:
                raise ValueError("Username is required when using password authentication")
            if not password:
                raise ValueError("Password is required when using password authentication")

        elif self.auth_method == "key_pair":
            if not user:
                raise ValueError("Username is required when using key pair authentication")
            if not private_key_path:
                raise ValueError("Private key path is required when using key pair authentication")

        elif self.auth_method == "oauth":
            if not oauth_token:
                raise ValueError("OAuth token is required when using OAuth authentication")

        self._initialize_session()

    def _load_private_key(self) -> bytes:
        """
        Load and process private key from file.

        Returns:
            bytes: The private key in bytes format required by Snowflake
        """
        try:
            with open(self.private_key_path, "rb") as f:
                p_key = serialization.load_pem_private_key(
                    f.read(), password=self.private_key_passphrase.encode() if self.private_key_passphrase else None
                )

            return p_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
        except Exception as e:
            raise ValueError(f"Failed to load private key: {str(e)}")

    def _initialize_session(self) -> None:
        """
        Initialize a Snowflake session using provided connection parameters.

        If initialization fails, sets the session to None.
        """
        try:
            self._session = Session.builder.configs(self._get_connection_params()).create()
        except Exception as e:
            print(f"Error initializing Snowflake session: {e}")
            self._session = None

    def _get_connection_params(self) -> Dict[str, str]:
        """
        Build the Snowflake connection parameters based on authentication method.

        Returns:
            Dict[str, str]: Dictionary containing connection parameters.
        """
        connection_parameters = {
            "account": self.account,
            "warehouse": self.warehouse,
        }

        # Add user if provided (required for password and key_pair auth)
        if self.user:
            connection_parameters["user"] = self.user

        if self.auth_method == "password":
            connection_parameters["password"] = self.password

        elif self.auth_method == "key_pair":
            connection_parameters.update({"private_key": self._load_private_key(), "authenticator": "SNOWFLAKE_JWT"})

        elif self.auth_method == "browser":
            connection_parameters["authenticator"] = "externalbrowser"

        else:  # oauth
            connection_parameters.update({"authenticator": "oauth", "token": self.oauth_token})
            if self.host:
                connection_parameters["host"] = self.host

        return connection_parameters

    def _exec(
        self,
        code: str,
    ) -> Any:
        """
        Execute a SQL statement in Snowflake and return the result.

        Args:
            code (str): SQL code to execute.

        Returns:
            Any: Result of the query execution.
        """
        if not self._session:
            self._initialize_session()

        try:
            sess_results = self._session.sql(code)
            return sess_results.collect()
        except Exception as e:
            raise e

    def delete_gnn(self, name: str):
        """
        Delete a GNN engine.

        :param name: Name of the GNN engine to delete.
        :type name: str
        :raises: Exception if the GNN engine is not found or deletion fails.
        """
        try:
            self._exec(f"CALL {self.app_name}.experimental.delete_engine('{ENGINE_TYPE_GNN}', '{name}');")
            return True
        except SnowparkSQLException as e:
            # Check if the error is specifically about engine not found
            if "engine not found" in str(e).lower():
                print(f"❌ GNN engine '{name}' not found")
                return False
            else:
                # Re-raise other SnowparkSQLExceptions
                raise
        except Exception as e:
            # Handle any other unexpected exceptions
            raise RuntimeError(f"Failed to delete GNN engine '{name}': {str(e)}") from e

    def resume_gnn(self, name: str):
        """
        Resume a previously created GNN engine.

        :param name: Name of the GNN engine to resume.
        :type name: str
        :raises: Exception if the GNN engine is not found or resume fails.
        """
        try:
            self._exec(f"CALL {self.app_name}.experimental.resume_engine_async('{ENGINE_TYPE_GNN}', '{name}');")
            return True
        except SnowparkSQLException as e:
            # Check if the error is specifically about engine not found
            if "engine not found" in str(e).lower():
                print(f"❌ GNN engine '{name}' not found")
                return False
            else:
                # Re-raise other SnowparkSQLExceptions
                raise
        except Exception as e:
            # Handle any other unexpected exceptions
            raise RuntimeError(f"Failed to resume GNN engine '{name}': {str(e)}") from e

    def get_gnn(self, name: str):
        """
        Retrieve details of a specific GNN engine.

        :param name: Name of the GNN engine to fetch.
        :type name: str
        :returns: A dictionary containing the engine's details.
        :rtype: dict
        :raises: Exception if the GNN engine is not found or retrieval fails.
        """
        try:
            results = self._exec(f"CALL {self.app_name}.experimental.get_engine('{ENGINE_TYPE_GNN}', '{name}');")
            return self.gnn_list_to_dicts(results)[0]
        except SnowparkSQLException as e:
            # Check if the error is specifically about engine not found
            if "engine not found" in str(e).lower():
                print(f"❌ GNN engine '{name}' not found")
            return False
        except Exception as e:
            # Handle any other unexpected exceptions
            raise RuntimeError(f"Failed to get GNN engine '{name}': {str(e)}") from e

    def create_gnn(
        self,
        name: str,
        size: str | None = None,
        settings: dict | None = None,
    ):
        """
        Create a new GNN engine in Snowflake.

        :param name: Name of the GNN engine.
        :type name: str
        :param size: Optional. Size specification for the engine. Defaults to "HIGHMEM_X64_S".
        :type size: Optional[Union[str, None]]
        :param settings: Optional. Additional engine settings. Defaults to an empty dictionary.
        :type settings: Optional[dict]
        :raises: Exception if the GNN engine already exists or creation fails.
        """
        if size is None:
            size = "HIGHMEM_X64_S"
        if settings is None:
            settings = {}
        engine_config: dict[str, Any] = {"settings": settings}

        try:
            self._exec(
                f"CALL {self.app_name}.experimental.create_engine('{ENGINE_TYPE_GNN}', '{name}', '{size}', {engine_config});"
            )
            return True
        except SnowparkSQLException as e:
            # Check if the error is specifically about engine already exists
            if "engine already exists" in str(e).lower():
                print(f"❌ GNN engine '{name}' already exists")
                return False
            else:
                # Re-raise other SnowparkSQLExceptions
                raise
        except Exception as e:
            # Handle any other unexpected exceptions
            raise RuntimeError(f"Failed to create GNN engine '{name}': {str(e)}") from e

    def list_gnns(self, state: str | None = None):
        """
        List available GNN engines, optionally filtered by state.

        :param state: Optional status filter (e.g., "RUNNING", "STOPPED"). Defaults to None.
        :type state: Optional[str]
        :returns: A list of dictionaries containing engine details.
        :rtype: list[dict]
        """

        where_clause = f"WHERE TYPE='{ENGINE_TYPE_GNN}'"
        where_clause = f"{where_clause} AND STATUS = '{state.upper()}'" if state else where_clause
        statement = f"SELECT NAME,ID,SIZE,STATUS,CREATED_BY,CREATED_ON,UPDATED_ON,SETTINGS \
                    FROM {self.app_name}.experimental.engines {where_clause};"
        results = self._exec(statement)
        return self.gnn_list_to_dicts(results)

    @staticmethod
    def gnn_list_to_dicts(results):
        """Convert raw Snowflake engine query results to a list of structured dictionaries."""
        if not results:
            return []

        processed_results = []

        for row in results:
            simplified_settings = {}
            for endpoint_name, endpoint_info in json.loads(row["SETTINGS"]).items():
                if endpoint_name == "mlflowendpoint":
                    if isinstance(endpoint_info, dict) and "ingress_url" in endpoint_info:
                        simplified_settings[endpoint_name] = f"https://{endpoint_info['ingress_url']}"

            processed_row = {
                "name": row["NAME"],
                "id": row["ID"],
                "size": row["SIZE"],
                "state": row["STATUS"],
                "created_by": row["CREATED_BY"],
                "created_on": row["CREATED_ON"],
                "updated_on": row["UPDATED_ON"],
                "settings": simplified_settings,
            }

            processed_results.append(processed_row)

        return processed_results
