import json
import uuid
from typing import Optional

import requests

from rai_gnns_experimental.common.job_models import JobTypes, PayloadTypes

from .connector import BaseConnector
from .utils import extract_error_message


class JobHandler:
    def __init__(self, connector: BaseConnector):
        self.connector = connector
        self.base_url = f"{connector.endpoint_url}/v1alpha1"

    @staticmethod
    def _print_json(response: requests.Response):
        """Helper function, print .json payload of a Response object."""
        json_payload = response.json()
        print(json.dumps(json_payload, indent=4))

    def _parse_request_exception(self, response):
        """Extracts and formats error message from a failed requests response."""
        try:
            error_detail = response.json().get("detail", "No detail provided")
            return f"❌ Error: {error_detail}"
        except (ValueError, AttributeError):
            return "❌ Error: Failed to parse error response"


class JobMonitor(JobHandler):
    """Helper class to monitor a single job."""

    def __init__(self, connector: BaseConnector, job_id: str, job_type: Optional[str] = None):
        super().__init__(connector)
        self.job_id = job_id
        self.job_type = job_type
        self.registered_models = []
        self._registered_model_name_list = []

    def get_status(self):
        """Get the current job status."""
        try:
            payload = {"payload_type": PayloadTypes.REQUEST_JOB_STATUS, "job_id": self.job_id}
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/create/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, json=payload, timeout=60)
                response.raise_for_status()
                response_data = response.json().get("data", {})
            else:
                response_data = self.connector.exec_job(payload)

            print(response_data)
            return response_data

        except requests.HTTPError:
            error_message = self._parse_request_exception(response)
            print(error_message)
            return None

        except Exception as e:
            err_msg = extract_error_message(str(e))
            print(f"❌ Error retrieving job status: {err_msg}")
            return None

    @property
    def model_run_id(self):
        """Get the current job status."""

        payload = {"payload_type": PayloadTypes.REQUEST_MLFLOW_RUN_ID, "job_id": self.job_id}

        try:
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/create/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, json=payload, timeout=60)
                response.raise_for_status()
                response_data = response.json().get("data", {})
                return response_data
            else:
                return self.connector.exec_job(payload)

        except requests.RequestException:
            print("❌ No model has been trained. Please train a model first.")
            return None
        except Exception:
            print("❌ No model has been trained. Please train a model first.")
            return None

    @property
    def experiment_name(self):
        """Get the experiment name for the current job."""

        try:
            payload = {"payload_type": PayloadTypes.REQUEST_JOB_STATUS, "job_id": self.job_id}
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/create/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, json=payload, timeout=60)
                response.raise_for_status()
                response_data = response.json().get("data", {})
            else:
                response_data = self.connector.exec_job(payload)

            return response_data["experiment_name"]

        except requests.HTTPError:
            error_message = self._parse_request_exception(response)
            print(error_message)
            return None

        except Exception as e:
            print(f"❌ Error retrieving job experiment name: {str(e)}")
            return None

    def register_model(self, model_name: str) -> None:
        """
        Registers a model in the MLflow Model Registry for the current job.

        :param model_name: The name to assign to the registered model.
        :type model_name: str
        """

        if self.job_type not in [JobTypes.TRAIN, JobTypes.TRAIN_INFERENCE]:
            print(f"❌ Cannot register model for job type '{self.job_type.value}'.")
            return None

        if not self.model_run_id:
            return None

        if model_name in self._registered_model_name_list:
            print(f"❌ Model '{model_name}' is already registered for job '{self.job_id}'")
            return None

        payload = {
            "payload_type": PayloadTypes.REGISTER_MODEL,
            "model_name": model_name,
            "model_run_id": self.model_run_id,
        }

        try:
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/create/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, json=payload, timeout=60)
                response.raise_for_status()
                registered_model = response.json().get("data", {})
            else:
                registered_model = self.connector.exec_job(payload)

            self.registered_models.append(registered_model)
            self._registered_model_name_list.append(registered_model["name"])

            print(
                f"✅ Successfully registered model '{registered_model['name']}' "
                f"with version '{registered_model['version']}' for job '{self.job_id}'"
            )

        except requests.RequestException as e:
            print(f"❌ Request error while registering model: {e}")
            return

        except Exception as e:
            err_msg = extract_error_message(str(e))
            print(f"❌ Error during model registration: {err_msg}")
            return

    def cancel(self):
        """Removes a job from the queue if the job is in the queue or terminates a running job if the job is active."""
        try:
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/cancel/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, timeout=60)
                response.raise_for_status()
                return self._print_json(response)
            else:
                self.connector.cancel_job(self.job_id)

        except requests.RequestException:
            error_message = self._parse_request_exception(response)
            print(error_message)
            return None

        except Exception as e:
            print(f"❌ Error canceling job: {str(e)}")
            return None

    def stream_logs(self):
        """Monitor logs for a specific job ID and display them to the user."""

        print(f"\nMonitoring logs for job ID: {self.job_id}")
        print("-" * 80)

        try:
            if self.connector.is_native_app:
                self._stream_logs_is_native_app()
            else:
                self._stream_logs_http_approach()
        except KeyboardInterrupt:
            print("\nStopped log streaming.")
        except Exception as e:
            print(f"Error streaming logs: {str(e)}")

        print("\nLog monitoring completed!")

    def _stream_logs_http_approach(self):
        """Stream logs using HTTP streaming approach."""
        url = f"{self.base_url}/jobs/logs/{self.job_id}"

        with requests.get(url, headers=self.connector.headers, stream=True, timeout=None) as response:
            if response.status_code != 200:
                print(f"Error accessing logs. Status code: {response.status_code}")
                print(response.text)
                return

            for line in response.iter_lines():
                if not line:
                    continue

                decoded_line = line.decode("utf-8")
                print(self.clean_log_message(decoded_line))

                # Stop after training completes
                if f"JOB_END:{self.job_id}" in decoded_line:
                    print("-" * 80)
                    print(f"Training job {self.job_id} completed!")
                    break

    def _stream_logs_is_native_app(self):
        """Stream logs using SQL approach with continuation token."""
        continuation_token = ""

        while True:
            response = self.connector.get_job_events(self.job_id, continuation_token)

            # Print event logs to stdout
            for event in response["events"]:
                print(self.clean_log_message(event["event"]["message"]))

            # Check if we need to continue fetching more logs
            continuation_token = response["continuation_token"]
            if not continuation_token:
                break

    @staticmethod
    def clean_log_message(log: str):
        if "| user_id" in log:
            clean_log = log.split("| user_id")[0].strip()
        else:
            clean_log = log

        return clean_log


class JobManager(JobHandler):
    """Helper class to monitor all jobs in queue."""

    def show_jobs(self):
        """Returns the queue status."""
        payload = {"payload_type": PayloadTypes.REQUEST_QUEUE_STATUS}

        try:
            if not self.connector.is_native_app:
                job_id = str(uuid.uuid4())
                url = f"{self.base_url}/jobs/create/{job_id}"
                response = requests.post(url, headers=self.connector.headers, json=payload, timeout=60)
                response.raise_for_status()
                response_data = response.json().get("data", {})
                return response_data
            else:
                return self.connector.exec_job(payload)

        except requests.RequestException:
            print(f"❌ Error getting queue status. Status code: {response.status_code}")
            return None
        except Exception:
            print("❌ Error getting queue status.")
            return None

    def fetch_job(self, job_id: str):
        """
        Fetch a job by its ID.

        :param job_id: Unique identifier of the job to fetch.
        :type job_id: str
        :returns: A dictionary or object representing the fetched job and its metadata.
        :rtype: dict or Job
        :raises ValueError: If the job ID is invalid or the job cannot be found.
        """
        job = JobMonitor(connector=self.connector, job_id=job_id)

        if job.get_status() is None:
            return None

        return job

    def cancel_job(self, job_id: str):
        """
        Cancel a job by its ID.

        Removes the job from the queue if it is queued, or terminates it if it is currently running.

        :param job_id: Unique identifier of the job to cancel.
        :type job_id: str
        :returns: The result of the cancel operation.
        :rtype: Any
        :raises ValueError: If the job cannot be found or is in a non-cancellable state.
        """
        job = self.fetch_job(job_id)

        if job is None:
            return None

        return job.cancel()
