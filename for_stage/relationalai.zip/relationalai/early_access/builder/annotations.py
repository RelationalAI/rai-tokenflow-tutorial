# In your_package/submodule.py
from .builder import Relationship

external = Relationship.builtins["external"]
concept_population = Relationship.builtins["concept_population"]
from_cdc = Relationship.builtins["from_cdc"]
