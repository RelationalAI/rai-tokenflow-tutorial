# GraphLib

This package is an exploratory translation of the Rel graphlib
to query builder. Essentially it's a collection of classes and
kernels over those classes. It's not intended to be user-facing;
chances are some user-facing interface will wrap what this sketch
evolves into.

## Installation [TODO]

For end usage:
```bash
...
```

For development and testing:
```bash
...
```

## Basic Usage [TODO]

```python
[... usage example ...]
```

## Testing [TODO]

Run the test suite with pytest:

```bash
pytest
```

## Requirements [TODO]

- relationalai
